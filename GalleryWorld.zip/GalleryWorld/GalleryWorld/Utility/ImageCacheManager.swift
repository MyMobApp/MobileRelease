//
//  ImageCacheManager.swift
//  GalleryWorld
//
//  Created by Mahesh TN on 24/04/25.
//

import UIKit

class ImageCacheManager {//Caching each image with its full img url
    static let shared = NSCache<NSString, UIImage>()
}
