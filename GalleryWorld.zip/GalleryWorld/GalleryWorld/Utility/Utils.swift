//
//  Utils.swift
//  GalleryWorld
//
//  Created by Mahesh TN on 25/04/25.
//

import UIKit

class Utils{
    
    static func showAlertMsg(title: String, message: String) {
        DispatchQueue.main.async {
            if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
               let rootVC = windowScene.windows.first(where: { $0.isKeyWindow })?.rootViewController {
                
                // Gettop most presented view controller
                var topVC = rootVC
                while let presentedVC = topVC.presentedViewController {
                    topVC = presentedVC
                }

                let alert = UIAlertController(
                    title: title,
                    message: message,
                    preferredStyle: .alert
                )
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                topVC.present(alert, animated: true)
            }
        }
    }
    
}
