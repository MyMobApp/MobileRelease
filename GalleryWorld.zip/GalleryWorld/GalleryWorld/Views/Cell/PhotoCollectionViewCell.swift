//
//  PhotoCollectionViewCell.swift
//  GalleryWorld
//
//  Created by Mahesh TN on 24/04/25.
//

import UIKit

class PhotoCollectionViewCell: UICollectionViewCell {
    
    
    // MARK: - @IBOutlet declaration
    @IBOutlet weak var imageView: UIImageView?
    @IBOutlet weak var itemName: UILabel!
    @IBOutlet weak var bgView: UIView!
    
    
    
    
    
    // MARK: - Local function

    
    func configure(with urlString: String) {
        
        guard let url = URL(string: urlString) else {
            print("Invalid URL: \(urlString)")
            return
        }
        let key = url.absoluteString as NSString

        // Check cache first
        if let cached = ImageCacheManager.shared.object(forKey: key) {
            print("Cache hit for \(urlString)")
            self.imageView?.image = cached
        } else {
            print("Cache miss for \(urlString)")
            self.imageView?.image = nil
            
            // Fetch the image asynchronously
            URLSession.shared.dataTask(with: url) { data, _, error in
                if let error = error {
                    print("Failed to load image: \(error.localizedDescription)")
                    return
                }
                
                // Ensure the data is valid
                guard let data = data, let image = UIImage(data: data) else {
                    print("Failed to convert data to image for URL: \(urlString)")
                    return
                }
                
                // Cache the image
                ImageCacheManager.shared.setObject(image, forKey: key)
                
                // Updating the UI on the main thread
                DispatchQueue.main.async {
                    self.imageView?.image = image
                }
            }.resume()
        }
    }

    
    
}



