//
//  ViewController.swift
//  GalleryWorld
//
//  Created by Mahesh TN on 24/04/25.
//

import UIKit


class ViewController: UIViewController{

    // MARK: - @IBOutlet declaration
    @IBOutlet weak var collectionView: UICollectionView!
    
    
    // MARK: - Local variable declaration
    var photos: [UnsplashPhoto] = []
    var currentPage = 1
    var isLoading = false

    
    
    // MARK: - Lifecycle functions
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.delegate = self
        collectionView.dataSource = self
        setupNavBar()
        loadPhotos()
    }
    
}


extension ViewController : UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout{
    
    
    // MARK: - UICollectionView DataSource

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return photos.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "PhotoCollectionViewCell", for: indexPath) as! PhotoCollectionViewCell
        cell.configure(with: photos[indexPath.item].urls.small)
        cell.itemName.text = AppConstants.MODEL_STRING + generateRandomNumToString()//Giving some random names
        cell.imageView?.contentMode = .scaleAspectFill
        cell.imageView?.clipsToBounds = true
        cell.bgView.styleRoundedWithShadow()
        return cell
    }
    
    
    
    
    // MARK: - UICollectionView Delegate
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        // Get the actual cell
        guard let cell = collectionView.cellForItem(at: indexPath) as? PhotoCollectionViewCell else { return }

        // Get the image URL and label text from the cell
        
        if let itemImage = cell.imageView?.image{
            
            let itemName = cell.itemName.text
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            let detailVC = storyboard.instantiateViewController(withIdentifier: "DisplayItemViewController") as! DisplayItemViewController
            detailVC.itemImage = itemImage
            detailVC.itemName = itemName ?? ""
            self.present(detailVC, animated: false)
          
            
        }
        
        
    }


    
    // MARK: - UICollectionViewDelegateFlowLayout for spacing
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = (collectionView.frame.width - 30) / 2
        return CGSize(width: width, height: width)
    }
    
    

    // MARK: - Infinite scroll
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height
        let height = scrollView.frame.size.height

        if offsetY > contentHeight - height * 1.5 {
            loadPhotos()
        }
    }
    
    
    
    
    
    // MARK: - Local functions
    
    func generateRandomNumToString() -> String {
        return String(Int.random(in: 100000...999999))
    }
    
    func loadPhotos() {
        guard !isLoading else { return }
        isLoading = true

        UnsplashAPI.shared.fetchPhotos(page: currentPage) { [weak self] newPhotos in
            guard let self = self else { return }
            self.photos += newPhotos
            self.currentPage += 1
            self.isLoading = false
            self.collectionView.reloadData()
        }
    }
    
    func setupNavBar(){
        
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationItem.title = "Home"
        self.navigationController?.navigationBar.backgroundColor = .systemCyan
        self.navigationController?.navigationBar.titleTextAttributes = [.foregroundColor : UIColor.white]

            navigationItem.rightBarButtonItem = UIBarButtonItem(
                image: UIImage(systemName: "xmark"),
                style: .plain,
                target: self,
                action: #selector(closeApp))
    }
    
    @objc func closeApp() {
        UIApplication.shared.perform(#selector(NSXPCConnection.suspend))
    }
    
}



