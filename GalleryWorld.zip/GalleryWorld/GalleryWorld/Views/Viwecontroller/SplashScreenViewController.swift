//
//  SplashScreenViewController.swift
//  GalleryWorld
//
//  Created by Mahesh TN on 24/04/25.
//

import UIKit

class SplashScreenViewController: UIViewController {
    
    
    // MARK: - Lifecycle functions
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .systemCyan
      
        NotificationCenter.default.addObserver(self,
             selector: #selector(appWillEnterForeground),
             name: UIApplication.willEnterForegroundNotification,
             object: nil)
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        NotificationCenter.default.removeObserver(self)
    }
    
    
   

}

extension SplashScreenViewController{
    
    
    
    // MARK: - local functions
    
    @objc func appWillEnterForeground() {
        // This is where you handle when the app comes back to foreground
        performNetworkCheck()
    }

    func showNoInternetAlert() {
        let alert = UIAlertController(title: "No Internet Connection",
                                      message: "Please check your network settings.",
                                      preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: {_ in
            
            UIApplication.shared.perform(#selector(NSXPCConnection.suspend))
        }))
        present(alert, animated: true)
    }

    
    
    func navigateToHomeScreen(){
        let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "ViewNavController")
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: false)
        
    }
    
    func performNetworkCheck(){
        
        NetworkManager.shared.checkConnection { isConnected in
            DispatchQueue.main.async {
                if isConnected {
                    print("Internet is available")
                    self.navigateToHomeScreen()
                } else {
                    self.showNoInternetAlert()
                }
            }
        }
    }
    
}
