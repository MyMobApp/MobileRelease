//
//  DisplayItemViewController.swift
//  GalleryWorld
//
//  Created by Mahesh TN on 24/04/25.
//

import UIKit

class DisplayItemViewController: UIViewController {
    
    
    // MARK: - @IBOutlet declaration
    @IBOutlet weak var outerView: UIView!
    @IBOutlet weak var itemNameLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var closeButton: UIButton!
    
    
    
    // MARK: - Local variable declaration
    var itemImage : UIImage? = nil
    var itemName : String? = nil
    
    
    // MARK: - Lifecycle functions
    override func viewDidLoad() {
        super.viewDidLoad()
        
        doInterfaceSetup()
        
        if let selectedItem = itemName{
            self.itemNameLabel.text = selectedItem
        }
        
        if let selectedItemImage = itemImage{
            self.imageView.image = selectedItemImage
        }
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        self.itemName = nil
        self.itemImage = nil
    }
    
    
    
    
   
    
}

extension DisplayItemViewController{
    
    
    // MARK: - @IBAction and local functions
    
    
    @IBAction func closeBtnACtion(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func doInterfaceSetup(){
        
        self.outerView.styleRoundedWithShadow()
        self.imageView.contentMode = .scaleAspectFill
        self.imageView.clipsToBounds = true
        self.closeButton.isUserInteractionEnabled = true
        self.closeButton.layer.cornerRadius = 10.0

    }
}
