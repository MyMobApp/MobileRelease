//
//  NetworkManager.swift
//  GalleryWorld
//
//  Created by Mahesh TN on 25/04/25.
//
import Foundation
import Network

class NetworkManager {
    
    // MARK: - Local variable declaration
    
    static let shared = NetworkManager()
    
    private let monitor = NWPathMonitor()
    private let queue = DispatchQueue(label: "NetworkMonitor")
    private var isMonitoring = false
    private(set) var isConnected: Bool = false
    
    
    
    // MARK: - Initialize
    private init() {}
    
    
    
    
    // MARK: - Other functions for checking internet connectivity
    
    func startMonitoring() {
        guard !isMonitoring else { return }

        monitor.pathUpdateHandler = { path in
            self.isConnected = path.status == .satisfied
            print("Network status changed: \(self.isConnected ? "Connected" : "No connection")")
        }
        
        monitor.start(queue: queue)
        isMonitoring = true
    }
    
    func stopMonitoring() {
        guard isMonitoring else { return }
        monitor.cancel()
        isMonitoring = false
    }

    // One-time check
    func checkConnection(completion: @escaping (Bool) -> Void) {
        let monitor = NWPathMonitor()
        let queue = DispatchQueue(label: "OneTimeInternetCheck")
        
        monitor.pathUpdateHandler = { path in
            completion(path.status == .satisfied)
            monitor.cancel()
        }
        
        monitor.start(queue: queue)
    }
}

