//
//  UnsplashAPI.swift
//  GalleryWorld
//
//  Created by Mahesh TN on 24/04/25.
//

import Foundation
import UIKit

class UnsplashAPI {
    
    
    static let shared = UnsplashAPI()
    private init() {}
    
    
    
    func fetchPhotos(query: String = AppConstants.API_ITEM_CATEGORY,page: Int = 1,perPage: Int = 10,completion: @escaping ([UnsplashPhoto]) -> Void) {
        
        
        let apiKey = AppConstants.API_ACCESS_KEY
        
        // Checking API key added or nor
        if apiKey == "insert_your_api_key_here" {
            print("Please provide your Unsplash API key in Config.xcconfig")
            
            //Show alert to the user (on main thread)
            Utils.showAlertMsg(title: "Missing API Key", message: "Please add your Unsplash API key to Config.xcconfig to continue")
            return //Skip the API call
        }
        
        // Continue with the network call if the key is valid
        let urlString = "https://api.unsplash.com/search/photos?page=\(page)&per_page=\(perPage)&query=\(query)&client_id=\(apiKey)"
        
        guard let url = URL(string: urlString) else { return }
        
        URLSession.shared.dataTask(with: url) { data, _, error in
            if let data = data {
                do {
                    let decoded = try JSONDecoder().decode(UnsplashSearchResult.self, from: data)
                    DispatchQueue.main.async {
                        completion(decoded.results)
                    }
                } catch {
                    Utils.showAlertMsg(title: "API Error!!!!", message: error.localizedDescription + " Please check your API credentials")
                }
            } else {
                Utils.showAlertMsg(title: "Error!", message: error?.localizedDescription ?? "Unknown error")
            }
        }.resume()
    }
    
    
    
    
    
    
    
    
    
    
}
