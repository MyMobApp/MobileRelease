//
//  PhotoModel.swift
//  GalleryWorld
//
//  Created by Mahesh TN on 24/04/25.
//

import Foundation


// MARK: - These structs are used for handling data from the API
struct UnsplashSearchResult: Decodable {
    let results: [UnsplashPhoto]
}

struct UnsplashPhoto: Decodable {
    let id: String
    let urls: UnsplashPhotoURLs
}

struct UnsplashPhotoURLs: Decodable {
    let thumb: String
    let small: String
    let regular: String
}

