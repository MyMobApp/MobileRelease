//
//  AppConstants.swift
//  GalleryWorld
//
//  Created by Mahesh TN on 24/04/25.
//

import UIKit

class AppConstants : NSObject{
    
    static let API_ITEM_CATEGORY : String = "car"
    static let API_ACCESS_KEY : String = Bundle.main.infoDictionary?["UNSPLASH_API_KEY"] as!String
    static let MODEL_STRING : String = "Model "
    
}
